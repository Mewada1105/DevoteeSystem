import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule,ReactiveFormsModule,FormControl,FormGroup,FormArray } from '@angular/forms';
import { LoginComponent } from './Components/login/login.component';
import { AdminComponent } from './Components/admin/admin.component';
import { DevoteeComponent } from './Components/devotee/devotee.component';
import { UserListComponent } from './Components/admin/Child/user-list/user-list.component';
import { CreateUserComponent } from './Components/admin/Child/create-user/create-user.component';

import { EditUserComponent } from './Components/admin/Child/edit-user/edit-user.component';
import { DonationsComponent } from './Components/admin/Child/donations/donations.component';
import { MypaymentsComponent } from './Components/devotee/Chils/mypayments/mypayments.component';
import { PayOnlineComponent } from './Components/devotee/Chils/pay-online/pay-online.component';
import { ProfileComponent } from './Components/devotee/Chils/profile/profile.component';
import { RouterModule, RouterOutlet } from '@angular/router';
import { HttpClient, HttpClientModule, provideHttpClient, withInterceptorsFromDi } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    AdminComponent,
    DevoteeComponent,
    UserListComponent,
    CreateUserComponent,
    EditUserComponent,
    DonationsComponent,
    MypaymentsComponent,
    PayOnlineComponent,
    ProfileComponent,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    
  ],
  providers: [provideHttpClient(withInterceptorsFromDi())],
  bootstrap: [AppComponent]
})
export class AppModule { }
