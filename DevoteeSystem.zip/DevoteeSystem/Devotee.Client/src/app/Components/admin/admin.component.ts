import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrl: './admin.component.css'
})
export class AdminComponent implements OnInit{

  constructor(private router:Router){

  }
  ngOnInit(): void {
    this.router.navigate(['admin/userlist'])
  } 
  CreateUser(){
    this.router.navigate(['admin/createuser']);
  }
  Donation(){
    this.router.navigate(['admin/donations']);
  }
  LogOut(){
    this.router.navigate(['login']);
  }

  edituser(){
    this.router.navigate(['admin/edituser']);
  }

}
