import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DevoteePostModel } from '../../../../Model/Devotee.Model';
import { ApiService } from '../../../../Services/api.service';
import { CreateUserComponent } from '../create-user/create-user.component';

@Component({
  selector: 'app-user-list',
  templateUrl: './user-list.component.html',
  styleUrl: './user-list.component.css'
})
export class UserListComponent implements OnInit{
   
    DevoteeList : Array<DevoteePostModel> ;

    constructor(private apiService:ApiService,private Router:Router){

    }
    ngOnInit(): void {
        this.apiService.GetDevotees().subscribe(
          res=>{
            this.DevoteeList = res;
            console.log("admin devoteelist:",this.DevoteeList);
          }
        );
    }

    EditUser(devotee:DevoteePostModel){
      console.log("called");
       this.apiService.EditDevotee(devotee);
        this.Router.navigate(['admin/createuser']);
    }
    
}
