import { Component, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, FormsModule, Validator, ValidatorFn, Validators } from '@angular/forms';
import { ApiService } from '../../../../Services/api.service';
import { DevoteePostModel } from '../../../../Model/Devotee.Model';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrl: './create-user.component.css'
})
export class CreateUserComponent implements OnInit{
  DevoteeForm: FormGroup;
  UserImage:File;

  constructor(private apiService: ApiService,private router:Router) {

    this.DevoteeForm = new FormGroup({
      firstname: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(55)]),
      middlename: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(55)]),
      lastname: new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(55)]),
      emaidId: new FormControl('', [Validators.required, Validators.email]),
      devoteeLoginId: new FormControl(''),
      initiationDate: new FormControl(new Date(), Validators.required),
      UserImageURL: new FormControl('', Validators.required),
      UserImage: new FormControl(File),
      flatno: new FormControl(0, Validators.min(1)),
      area: new FormControl('', Validators.required),
      city: new FormControl('', Validators.required),
      state: new FormControl('', Validators.required),
      pincode: new FormControl(0, [Validators.required, Validators.pattern(/^[0-9]+$/), Validators.maxLength(6)])
    });

  }
  ngOnInit(): void {
    this.DevoteeForm.patchValue({
      ...this.apiService.DevoteeEdit
    });
  }

  FileInput(target: any) {
    this.UserImage = target.files[0];
  }

  CreateDevotee() {
    console.log(this.DevoteeForm.value);

    let Devotee: DevoteePostModel = { ...this.DevoteeForm.value, createdByID: 6, createdDate: new Date(), updatedById: 6, updatedDate: new Date(),UserImage : this.UserImage}

    console.log(Devotee);
    this.apiService.PostDevotee(Devotee).subscribe( res=>{
      
        this.router.navigate(["admin/userlist"])
      
    });

    
    // this.apiService.GetDevotees().subscribe(res => console.log("Get res: ", res));
  }

  get f(): { [key: string]: AbstractControl } {
    return this.DevoteeForm.controls;
  }


  static EditDevotee(Devotee:DevoteePostModel){
      
  }
}
