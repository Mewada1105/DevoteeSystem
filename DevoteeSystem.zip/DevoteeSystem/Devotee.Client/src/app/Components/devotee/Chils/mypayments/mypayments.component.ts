import { Component } from '@angular/core';

@Component({
  selector: 'app-mypayments',
  templateUrl: './mypayments.component.html',
  styleUrl: './mypayments.component.css'
})
export class MypaymentsComponent {

}
