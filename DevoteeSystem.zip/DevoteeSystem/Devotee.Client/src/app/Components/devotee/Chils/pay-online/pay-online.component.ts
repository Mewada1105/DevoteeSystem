import { Component } from '@angular/core';

@Component({
  selector: 'app-pay-online',
  templateUrl: './pay-online.component.html',
  styleUrl: './pay-online.component.css'
})
export class PayOnlineComponent {

}
