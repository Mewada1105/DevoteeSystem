import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../Services/api.service';
import { DevoteePostModel } from '../../Model/Devotee.Model';

@Component({
  selector: 'app-devotee',
  templateUrl: './devotee.component.html',
  styleUrl: './devotee.component.css'
})
export class DevoteeComponent implements OnInit{

  devoteeData : DevoteePostModel;
  constructor(private apiservice:ApiService){

  }


  ngOnInit(): void {
    this.devoteeData =  this.apiservice.LoggedInDevotee;
    console.log("after login devotee:",this.devoteeData);
  }

}
