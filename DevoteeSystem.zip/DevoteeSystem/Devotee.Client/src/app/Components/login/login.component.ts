import { Component } from '@angular/core';
import { ReactiveFormsModule, Form, FormsModule, FormControl, FormGroup, Validators, AbstractControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiService } from '../../Services/api.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm: FormGroup;
  val = true;
  otpVal = true;
  InvalidCreds: string = ''


  constructor(private router: Router, private apiservice: ApiService) {
    this.loginForm = new FormGroup({
      UserName: new FormControl('', Validators.required),
      Password: new FormControl('', Validators.required),
      Role: new FormControl('', Validators.required),
      OTP: new FormControl(''),

    })
  }

  get f(): { [key: string]: AbstractControl } {
    return this.loginForm.controls;
  }

  Login() {
    let user: string = this.loginForm.get('Role')?.value;
    let UserName: string = this.loginForm.get('UserName')?.value;
    let Password: string = this.loginForm.get('Password')?.value;
    console.log(this.loginForm.valid);

    if (user == 'admin') {
      if (UserName == 'admin' && Password == 'admin') {
        this.InvalidCreds = '';

        this.router.navigate(['admin']);
 

      }
      else{
        
        this.InvalidCreds = 'Invalid user/password/role';
      }

    }
    else {
      this.DevoteeLogin(UserName, Password);
    }
  }


  DevoteeLogin(username: string, password: string) {
    this.val = false;
    this.loginForm.get('OTP')?.addValidators(Validators.required);

    if (password == 'password') {
      this.apiservice.DevoteeLogin(username).subscribe(res => {
        this.apiservice.LoggedInDevotee = res;
        console.log("Devotee after Login ::",this.apiservice.LoggedInDevotee);
      });
    }else{
      this.InvalidCreds = 'Invalid user/password/role';

    }

  }

  OnValueChangeOfRole(role: string) {
    console.log(role);
    if (role == 'devotee') {
      this.val = false
    } else {
      this.val = true
      this.loginForm.get('OTP')?.addValidators(Validators.required);
    }
  }
}
