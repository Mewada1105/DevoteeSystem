import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Devotee, DevoteePostModel } from '../Model/Devotee.Model';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  URL: string = 'https://localhost:7068/api/devotees';
  LoggedInDevotee:DevoteePostModel;
  DevoteeEdit:DevoteePostModel;
  constructor(private httpClient: HttpClient) {

  }

  GetDevotees():Observable<Array<DevoteePostModel>>{
    return this.httpClient.get<Array<DevoteePostModel>>(this.URL)
  }

  DevoteeLogin(username:string):Observable<DevoteePostModel>{
      return this.httpClient.post<DevoteePostModel>(`${this.URL}/DevoteeLogin`,{username});
  }

  PostDevotee(devotee: DevoteePostModel): Observable<DevoteePostModel> {

    const formData = new FormData();
    for(let key in devotee){
      const value : string | Blob = (devotee as any)[key]
      formData.set(key, value)
    }
    return this.httpClient.post<DevoteePostModel>(this.URL, formData);

  }

    EditDevotee(devotee : DevoteePostModel){
      this.DevoteeEdit = devotee;
    }
}
