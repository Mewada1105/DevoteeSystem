import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './Components/login/login.component';
import { AdminComponent } from './Components/admin/admin.component';
import { UserListComponent } from './Components/admin/Child/user-list/user-list.component';
import { CreateUserComponent } from './Components/admin/Child/create-user/create-user.component';
import { EditUserComponent } from './Components/admin/Child/edit-user/edit-user.component';
import { DonationsComponent } from './Components/admin/Child/donations/donations.component';

const routes: Routes = [
  {
    path:'login',component:LoginComponent
  },
  {
    path:'',component:LoginComponent
  },
  {
    path:'admin',component:AdminComponent,
    children:[
      {
        path:'userlist' ,component:UserListComponent
      },
      {
        path:'createuser',component:CreateUserComponent
      },
      {
        path:'donations' , component:DonationsComponent
      },
      {
        path:'edituser',component:EditUserComponent
      }
    ]
  },
  


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
