﻿namespace Devotee.Server.Repository
{
    public interface IRespository
    {
    }
}
