﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Devotee.Server.Migrations.AppIdentityDb
{
    /// <inheritdoc />
    public partial class dsda : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "DevoteeId",
                table: "AspNetUsers",
                type: "int",
                nullable: true,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "IsDevotee",
                table: "AspNetUsers",
                type: "bit",
                nullable: true,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "DevoteeId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "IsDevotee",
                table: "AspNetUsers");
        }
    }
}
