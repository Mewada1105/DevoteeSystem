﻿using Devotee.Server.Identity;
using Devotee.Server.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;

namespace Devotee.Server.Context
{
    public class DevoteeDbContext : DbContext
    {
        private readonly IConfiguration configuration;

        public DevoteeDbContext(DbContextOptions<DevoteeDbContext> Options, IConfiguration configuration)
            : base(Options)
        {
            this.configuration = configuration;
        }
        public DbSet<Address> Addresses { get; set; }
        public DbSet<Devotees> Devotees { get; set; }

        public DbSet<Donation> Donations { get; set; }
        public DbSet<UserImage> UserImages { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(configuration.GetConnectionString("SystemDB"));
        }
    }
}
