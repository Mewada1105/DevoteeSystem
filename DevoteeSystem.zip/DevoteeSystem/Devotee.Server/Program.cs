using Devotee.Server.AutoMapper;
using Devotee.Server.Context;
using Devotee.Server.Extension;
using Devotee.Server.Identity;
using Devotee.Server.SeedData;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<AppIdentityDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("UsersDB")));
builder.Services.AddDbContext<DevoteeDbContext>(options => options.UseSqlServer(builder.Configuration.GetConnectionString("SystemDB")));
builder.Services.AddIdentityService(builder.Configuration);
builder.Services.AddAutoMapper(typeof(MappingProfiles));

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

using (var scope = app.Services.CreateScope())
{
   var services = scope.ServiceProvider;
    var loggerFactory = services.GetRequiredService<ILoggerFactory>();
    try
    {
        RoleManager<AppRole> roleManager = services.GetRequiredService<RoleManager<AppRole>>();
        await IdentitySeed.SeedUser(roleManager);
    }
    catch (Exception ex) {
        var logger = loggerFactory.CreateLogger<Program>();
        logger.LogError(ex.Message);

    }
}


// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}



app.UseHttpsRedirection();

app.UseCors(
    options =>
    {
        options.AllowAnyOrigin()
        .AllowAnyMethod()
        .AllowAnyHeader();
    });

app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
