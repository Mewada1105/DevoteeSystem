﻿using Devotee.Server.Models;

namespace Devotee.Server.Models
{
    public class Address:BaseEntity
    {
        public int flatnumber {  get; set; }
        public string area { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public string pincode { get; set; }
        public ICollection<Devotees> Devotees { get; set; }
    }
}
