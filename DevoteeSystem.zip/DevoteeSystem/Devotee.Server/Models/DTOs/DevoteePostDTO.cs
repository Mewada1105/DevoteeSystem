﻿namespace Devotee.Server.Models.DTOs
{
    public class DevoteePostDTO
    {
        public string firstname { get; set; }
        public string middlename { get; set; }
        public string lastname { get; set; }
        public string EmaidId { get; set; }
        public DateTime InitiationDate { get; set; }
        public int flatno { get; set; }
        public string area { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public int pincode { get; set; }

        public string UserImageURL { get; set; }

        public IFormFile UserImage { get; set; }
        public int CreatedByID { get; set; }
        public int UpdatedByID { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedDate { get; set; }
    }
}
