﻿namespace Devotee.Server.Models
{
    public class Donation:BaseEntity
    {
        public int DonationAmount { get; set; }
        public DateTime DonationDate { get; set; }

        public int year { get; set; }
        public int month { get; set; }  
        public Devotees Devotee { get; set; }

        public int CreatedByID { get; set; }
        public DateTime CreatedDate { get; set; }
        public int UpdatedByID { get; set; }
        public DateTime UpdatedDate { get; set; }
    }
}
