﻿using Devotee.Server.Models;

namespace Devotee.Server.Models
{
    public class Devotees:BaseEntity
    {
        public string firstname {  get; set; }
        public string middlename {  get; set; }
        public string lastname { get; set; }
        public string EmaidId { get; set; }
        public string DevoteeLoginId { get; set;}
        public DateTime InitiationDate { get; set; }    
        public int flatno { get; set; }
        public string area { get; set; }
        public string city { get; set; }
        public string state { get; set; }
        public int pincode { get; set; }

        public UserImage UserImage { get; set; }
        public string UserImageURL { get; set; }

        public ICollection<Donation> Donations { get; set; }
        public int CreatedByID { get; set; }
        public int UpdatedByID { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime UpdatedDate { get; set; }

    }
}
