﻿namespace Devotee.Server.Models
{
    public class BaseEntity
    {
        public int Id { get; set; }
    }
}
