﻿namespace Devotee.Server.Interfaces
{
    public class LoginModel
    {
        public string user { get; set; }
        public string pass { get; set; }
    }
}
