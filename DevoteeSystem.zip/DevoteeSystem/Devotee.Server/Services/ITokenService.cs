﻿using Devotee.Server.Identity;

namespace Devotee.Server.Services
{
    public interface ITokenService
    {
        public  Task<string> CreateToken(AppUser User);
    }
}
