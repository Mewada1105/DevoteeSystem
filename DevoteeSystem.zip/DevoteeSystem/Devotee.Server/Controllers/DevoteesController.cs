﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Devotee.Server.Context;
using Devotee.Server.Models;
using Devotee.Server.Models.DTOs;
using AutoMapper;
using Azure.Identity;
using Devotee.Server.AWS;
using Microsoft.AspNetCore.Identity;
using Devotee.Server.Identity;
using Devotee.Server.Interfaces;
using Devotee.Server.Identity.IdentityDTOs;
///using Devotee.Server.AWS;

namespace Devotee.Server.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DevoteesController : ControllerBase
    {
        private readonly DevoteeDbContext _context;
        private readonly IMapper mapper;
        private readonly UserManager<AppUser> userManager;

        public DevoteesController(DevoteeDbContext context,IMapper Mapper,UserManager<AppUser> userManager)
        {
            _context = context;
            mapper = Mapper;
            this.userManager = userManager;
        }

        [HttpPost("DevoteeLogin")]
        public async Task<ActionResult<Devotees>> LoginDevotee(LoginDevoteeDTO dto)
        {
            try
            {
                Devotees devotee = await _context.Devotees.Where(d=>d.DevoteeLoginId == dto.username).FirstOrDefaultAsync();
                AppUser DevoteeUser = await userManager.FindByNameAsync(dto.username);
                     
                if (devotee == null || DevoteeUser==null) {

                    return NotFound("Devotee Not found");
                }

                
                return devotee;

            }
            catch (Exception ex) {
                return BadRequest(ex.Message);
            }
        }

        // GET: api/Devotees
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Devotees>>> GetDevotees()
        {
            var data = await _context.Devotees.ToListAsync();
            return  data;
        }

        // GET: api/Devotees/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Devotees>> GetDevotee(int id)
        {
            try
            {
                var devotee = await _context.Devotees.FindAsync(id);

                if (devotee == null)
                {
                    return NotFound();
                }

                return devotee;
            }
            catch(Exception ex) 
            {
                return BadRequest(ex.Message);

            }
        }

        // PUT: api/Devotees/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("{id}")]
        public async Task<ActionResult<Devotees>> PutDevotee(int id, DevoteePostDTO devotees)
        {

            Devotees devotee = await _context.Devotees.Where(d=>d.Id == id).FirstOrDefaultAsync();

            devotee.firstname = devotees.firstname;
            devotee.middlename = devotees.middlename;
            devotee.flatno = devotees.flatno;
            devotee.lastname = devotees.lastname;
            devotee.area = devotees.area;
            devotee.city = devotees.city;
            devotee.state = devotees.state;
            devotee.pincode = devotees.pincode;
            devotee.InitiationDate = DateTime.Now;
            devotee.EmaidId = devotees.EmaidId;
            devotee.UserImage = devotees.UserImage as UserImage;
            devotee.UserImageURL = devotees.UserImageURL;
            devotee.CreatedByID = devotees.CreatedByID;
            devotee.UpdatedByID = devotees.UpdatedByID;
            devotee.CreatedDate = DateTime.Now;
            devotee.UpdatedDate = DateTime.Now;
            devotee.DevoteeLoginId = $"{DateTime.Now.Year}-{devotee.firstname.Substring(0, 2)}-{devotee.lastname.Substring(0, 2)}-{DateTime.Now.Month}";


            _context.Entry(devotee).State = EntityState.Modified;
           
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!DevoteeExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return devotee;
        }

        // POST: api/Devotees
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPost]
        public async Task<ActionResult<DevoteeDTO>> RegisterDevotee(DevoteePostDTO devotee)
        {
             
            try
            {
                if (devotee == null)
                {
                    return BadRequest();

                }
            

                await UploadUserImage.UploadDevoteeImage(devotee.UserImage);
                var stream = devotee.UserImage.OpenReadStream();

                UserImage userImage =  new UserImage() { 
                    name = devotee.UserImage.FileName,
                    size = devotee.UserImage.Length.ToString(),
                    lastModified = devotee.UserImage.Headers.LastModified,
                    lastModifiedDate = DateTime.Now,
                    webkitRelativePath = ""
                };
                await _context.UserImages.AddAsync(userImage);

               await _context.SaveChangesAsync();
                Devotees devotee1  = new Devotees() {

                    firstname = devotee.firstname,
                    middlename = devotee.middlename,
                    flatno = devotee.flatno,
                    lastname = devotee.lastname,
                    area = devotee.area,
                    city = devotee.city,
                    state = devotee.state,
                    pincode = devotee.pincode,
                    InitiationDate = DateTime.Now,
                    EmaidId = devotee.EmaidId,
                    UserImage = userImage,
                    UserImageURL = devotee.UserImageURL,
                    CreatedByID = devotee.CreatedByID,
                    UpdatedByID = devotee.UpdatedByID,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    DevoteeLoginId = $"{DateTime.Now.Year}-{devotee.firstname.Substring(0, 2)}-{devotee.lastname.Substring(0, 2)}-{DateTime.Now.Month}"
                    
                };
               
                
                await _context.Devotees.AddAsync(devotee1);
                await _context.SaveChangesAsync();


                AppUser devoteeuser = new AppUser()
                {
                    UserName = devotee1.DevoteeLoginId,
                    PassWord = "password",
                    IsDevotee = true,
                    DevoteeId = devotee1.Id,
                    Role = "devotee",
                    Email = devotee1.EmaidId,
                    LoginId = devotee1.DevoteeLoginId,
                    
                };

                var createres= await userManager.CreateAsync(devoteeuser);
                var roleres = await userManager.AddToRoleAsync(devoteeuser, "devotee");

                if(! createres.Succeeded || !roleres.Succeeded)
                {
                    return StatusCode(400);
                }


                return Ok();

            }
            catch (Exception ex) { 
                return BadRequest(ex.Message);
            }
        }


        
        // DELETE: api/Devotees/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDevotee(int id)
        {
            var devotee = await _context.Devotees.FindAsync(id);
            if (devotee == null)
            {
                return NotFound();
            }

            _context.Devotees.Remove(devotee);
            await _context.SaveChangesAsync();

            return NoContent();
        }

        private bool DevoteeExists(int id)
        {
            return _context.Devotees.Any(e => e.Id == id);
        }
    }
}
