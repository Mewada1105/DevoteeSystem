﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Amazon.S3.Transfer;
using Amazon.Util.Internal;
using Microsoft.AspNetCore.Mvc;
namespace Devotee.Server.AWS
{
    public class UploadUserImage
    {
        public static async Task UploadDevoteeImage(IFormFile file)
        {

            RegionEndpoint regionEndpoint = RegionEndpoint.APSouth1;
            using (var client = new AmazonS3Client(regionEndpoint))
                {
                    using (var newMemoryStream = new MemoryStream())
                    {
                        file.CopyTo(newMemoryStream);

                        var uploadRequest = new TransferUtilityUploadRequest
                        {
                            InputStream = newMemoryStream,
                            Key = file.FileName,
                            BucketName = "devotee-system-user-images",
                            CannedACL = S3CannedACL.PublicRead
                        };

                        var fileTransferUtility = new TransferUtility(client);
                        await fileTransferUtility.UploadAsync(uploadRequest);
                    }
                }
            
            //RegionEndpoint regionEndpoint = RegionEndpoint.APSouth1;
            // AmazonS3Client  s3Client = new AmazonS3Client(regionEndpoint);
            //try
            //{
            //    var request = new PutObjectRequest()
            //    {
            //        BucketName = "devotee-system-user-images",
            //        ContentBody = File as FileStream,
            //       Key = File.FileName,

            //    };

            //    var response = await s3Client.PutObjectAsync(request);
            //    if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
            //    {
            //        Console.WriteLine("Bucket successfully Created");
            //    }
        
            //catch (AmazonS3Exception e)
            //{
            //    Console.Write(e.Message);
            //}
            //catch (Exception e) { 
            //    Console.Write(e.Message);
            //}
           
        }
    }
}
