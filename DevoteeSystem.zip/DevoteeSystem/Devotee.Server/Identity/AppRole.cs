﻿using Microsoft.AspNetCore.Identity;

namespace Devotee.Server.Identity
{
    public class AppRole:IdentityRole<int>
    {

    }
}
