﻿namespace Devotee.Server.Identity.IdentityDTOs
{
    public class LoginDevoteeDTO
    {
        public string username { get; set; }

    }
}
