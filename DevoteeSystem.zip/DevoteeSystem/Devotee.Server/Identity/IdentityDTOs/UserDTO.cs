﻿namespace Devotee.Server.Identity.IdentityDTOs
{
    public class UserDTO
    {
        public int DevoteeId { get; set; }
        public string Token { get; set; }
        public string UserName { get; set; }
        
    }
}
