﻿using AutoMapper;
using Devotee.Server.Models;
using Devotee.Server.Models.DTOs;

namespace Devotee.Server.AutoMapper
{
    public class MappingProfiles:Profile
    {
        public MappingProfiles()
        {
            CreateMap<Devotees,DevoteeDTO>();
        }
    }
}
